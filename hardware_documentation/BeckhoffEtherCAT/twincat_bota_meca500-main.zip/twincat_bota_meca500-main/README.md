## TwinCAT3 project example for Bota Systems sensors ##

## Overview ##

This software provides an example of a TwinCAT3 project that uses Bota Systems sensors for feedback control of a Mecademic Meca500 robot arm.

**Authors(s):** Martin Wermelinger

**Contact:** Bota Systems AG, sw-support@botasys.com

## Setup ##

You can find instructions on how to connect a Rokubi or Medusa Sensor to a Mecademic Meca500 through EtherCAT on Mecademic's [support page](https://support.mecademic.com/support/solutions/articles/64000264039-meca500-bota-systems-rokubi-force-sensor-integration).

## Configure sensor ##

Make sure that the sensor is detected as device on your PLC and listed underneath an EtherCAT master device.

<img src="imgs/twincat_io_devices.png" alt="devices scaled" width="373"/>

Activate configuration and restart TwinCAT in Run Mode (this restart will be done automatically when you click the Activate configuration button). In Run Mode, the Bota Systems sensor will start sending data, but allows you to configure the sensor's parameters in order to receive the correct values.

<img src="imgs/twincat_run_system.png" alt="devices scaled" width="373"/>

Double-click on the sensor's box and choose the CoE - Online tab. The CoE (CANopen over EtherCAT) is the method used by the sensor to send its data over the communication lines. In this can you can configure the sensor's force-torque offset, sample rate or temperature compensation, for example.

<img src="imgs/twincat_coe.png" alt="devices scaled" width="404"/>

Configure the Force Torque Filter (8006:0) and Device configuration (8010:0) according to your needs. We recommend to set the Sinc length to obtain the desired sampling rate (8011). Additional smoothing of the signal can be achieved by enabling the FIR filter. To save the configuration, send '1' on the control command (8030:01).

<img src="imgs/twincat_config_sensor.png" alt="devices scaled" width="400"/>

## Usage ##

The example code features Bota Systems sensors and a Mecademic Meca500 being used with Beckhoff TwinCAT 3 over EtherCAT. It can be used with different Beckhoff IPCs or other EtherCAT based PCs.

This example features a Function Block to interface the sensor and shows how to offset and (additionally) filter the signal. The FT sensor signal is used in different feedback application through admittance control. The application can be selected through the `DesMotionState` variable:
* `DesMotionState:=40` Hand-guidance controller
* `DesMotionState:=50` Force-track controller
* `DesMotionState:=60` Force-track + velocity controller
* `DesMotionState:=70` 'Polishing' controller (contour following)

# Bugs & Feature Requests #

Please report bugs and request features using the [Issue Tracker](https://gitlab.com/botasys/twincat_bota_meca500/-/issues).

